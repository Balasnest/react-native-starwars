import React from 'react';
import { Text, View, Image, StyleSheet, ImageBackground } from 'react-native';
import { Actions } from 'react-native-router-flux';
import {Button} from '../src/common';


class Login extends React.Component {

	render(){
		const { container, btnStyle } = styles;
		return(
			<View style={container}> 
				<Text> Hello Login </Text>
				<Button> Next Screen </Button> 
			</View>
		);
	}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnStyle: {
  	backgroundColor: 'red'
  }
});

export default Login;